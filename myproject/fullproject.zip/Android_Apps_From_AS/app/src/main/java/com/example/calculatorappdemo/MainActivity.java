package com.example.calculatorappdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView result;
EditText nomber1,nomber2;
Button button,button2,button3,button4;
float rest;
int num1,num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result=(TextView)findViewById(R.id.RRRR);
        nomber1=(EditText)findViewById(R.id.nomber1);
        nomber2=(EditText)findViewById(R.id.nomber2);
        button=(Button)findViewById(R.id.button);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        button4=(Button)findViewById(R.id.button4);
       button.setOnClickListener(
               new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                        num1=Integer.parseInt(nomber1.getText().toString());
                        num2=Integer.parseInt(nomber2.getText().toString());
                        rest=num1+num2;
                        result.setText(String.valueOf(rest));

                   }
               }
       );
       button2.setOnClickListener(
               new View.OnClickListener(){
                   @Override
                   public void onClick(View v) {
                       num1=Integer.parseInt(nomber1.getText().toString());
                       num2=Integer.parseInt(nomber2.getText().toString());
                       rest=num1-num2;
                       result.setText(String.valueOf(rest));

                   }
               }
       );
        button3.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        num1=Integer.parseInt(nomber1.getText().toString());
                        num2=Integer.parseInt(nomber2.getText().toString());
                        rest=num1*num2;
                        result.setText(String.valueOf(rest));

                    }
                }
        );
        button4.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        num1=Integer.parseInt(nomber1.getText().toString());
                        num2=Integer.parseInt(nomber2.getText().toString());
                        rest=num1/num2;
                        result.setText(String.valueOf(rest));

                    }
                }
        );

    }
}
